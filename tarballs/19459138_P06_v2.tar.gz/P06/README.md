./
├── AssignmentTask
│   ├── Convolute.class
│   ├── Convolute.java
│   ├── Image.class
│   ├── Image.java
│   ├── ImagePsuedo.txt
│   ├── ImageTestHarness.class
│   ├── ImageTestHarness.java
│   ├── Kernel.class
│   └── Kernel.java
├── Date.class
├── Date.java
├── DateTestHarness.class
├── DateTestHarness.java
├── Date.txt
├── Main.class
├── Main.java
├── README.md
├── TestObj.class
└── TestObj.java

1 directory, 19 files
