import java.util.*;
public class TestObj
{
    public static void main(String[] args)
    {
        Date christmas = new Date(45,12,2020);
        System.out.println(christmas.toString());
    }
}
