import java.util.*;

public class JavaExpressions
{
    public static void main(String[] args)
    {
        String marvel = "Avengers";
        double x = 314.219, y = 240.213;
        int mcu = 1999, prime = 614, cap = 2;

        int myVar = marvel + prime;
        System.out.println(myVar);
    }

}
