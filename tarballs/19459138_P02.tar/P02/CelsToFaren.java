// FILE: CelsToFaren.java
// AUTHOR: Connor Kuljis
// USERNAME: 19459138
// UNIT: PDI
// PURPOSE: Converts celcius to farenheit
// REFERENCE: None
// COMMENTS: For Prac2 of PDI
// REQUIRES:
// LAST MOD: 03/03/2020

import java.util.*;

public class CelsToFaren
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        double tempInCels, farenheit; 

        System.out.println("Please enter the temperature in Celsius (c)");
        tempInCels = sc.nextDouble();
       
        farenheit = ((tempInCels * 9.0) / 5.0) + 32.0;

        System.out.println("Temp in farenheit: " + farenheit);
    }
}
