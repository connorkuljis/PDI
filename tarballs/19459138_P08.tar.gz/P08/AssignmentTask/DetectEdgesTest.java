import java.util.*;

public class DetectEdgesTest
{
    public static void main(String[] args)
    {
        DetectEdges.detectEdges();
    }
}
